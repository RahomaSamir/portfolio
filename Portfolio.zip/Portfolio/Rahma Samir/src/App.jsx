import React from 'react';
import Aboutme from './component/aboutme/Aboutme';
import Footer from './component/footer/Footer';
import Herosection from './component/hero-section/Herosection';
import Navbar from './component/navbar/Navbar';
import Projects from './component/projects/Projects';
import Skills from './component/skills/Skills';
import '/Users/User/Desktop/Portfolio/session/src/bootstrap/dist/css/bootstrap.min.css';
import '/Users/User/Desktop/Portfolio/session/src/bootstrap/dist/js/bootstrap.bundle.js';
const App = () =>{
    return(
        <React.Fragment>
            
            <Aboutme/>
            <Footer/>
            <Herosection/>
            <Navbar/>
            <Skills/>
            <Projects/>

        </React.Fragment>
    );
    
}
export default App;