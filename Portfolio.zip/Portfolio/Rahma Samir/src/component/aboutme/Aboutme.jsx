import React from 'react';
import './aboutme.module.css';

function Bio() {
    return (
        <section id="bio">
            <div className="container">
                <h2>BIO:</h2>
                <p>Innovative Front End Developer with 7 months of experience building and maintaining responsive websites in the recruiting industry.</p>
                <p>Bachelor of Computer Science</p>
                <p>7 months of experience in Front End Development.</p>
                <a className="btn btn-primary" href="#" download>Download CV</a>
            </div>
        </section>
    );
}

export default Bio;