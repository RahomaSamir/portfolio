import React from 'react';
import img from '/Users/User/Desktop/Portfolio/session/src/assets/download.jpg';
import './hero-section.module.css';

export default function MainPart() {
    return (
        <div>
    <div class="container">
        <h2><span class="typing-animation">Hello, I'm Rahma Samir</span></h2>
        <h4>
            <span class="typing-animation">
              I specialize in developing the frontend.<br />
              I take great constantly try to improve my skills.
            </span>
          </h4>

      <div class="col-md-5">
        <img src={img} alt="Images" />
      </div>
    </div>
        </div>
    )
}
