import React from 'react';

export default function navbar() {
    return (<div>
    <nav class="navbar navbar-expand-lg navbar-light bg-light" style="margin-left: 15px;">
      <a class="navbar-brand" href="#">portfolio</a>

      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item active" style="margin-left: 900px;">
            <a class="nav-link" href="#">Home</a>
          </li>
          <li class="nav-item" style="margin-left: 20px;">
            <a class="nav-link" href="#">Bio</a>
          </li>
          <li class="nav-item" style="margin-left: 20px;">
            <a class="nav-link" href="#">Skills</a>
          </li>
          <li class="nav-item" style="margin-left: 20px;">
            <a class="nav-link" href="#">Projects</a>
          </li>
          <li class="nav-item" style="margin-left: 20px;">
            <a class="nav-link" href="#">Contact us</a>
          </li>
        </ul>
      </div>
    </nav>
    </div >
    )
}
