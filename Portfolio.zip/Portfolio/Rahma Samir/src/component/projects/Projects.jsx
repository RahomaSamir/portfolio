import React from 'react'
import './projects.module.css';
import img1 from '/Users/User/Desktop/Portfolio/session/src/assets/r.jpg'
import img2 from '/Users/User/Desktop/Portfolio/session/src/assets/rr.png'
import img3 from '/Users/User/Desktop/Portfolio/session/src/assets/rrr.png'


export default function Projects(){
    return (<div>  

    <div class="container">
      <h1> Projects :</h1>
        <div class="row">
          <div class="col-4">
            <div class="box">
              <div class="project-image">
              <img src={img1} alt="Image Description"/>
            </div></div>
          </div>
          <div class="col-4">
            <div class="box">
            <div class="project-image">
              <img src={img2} alt="Image Description"/>
            </div></div></div>
          <div class="col-4">
            <div class="box">
            <div class="project-image">
              <img src={img3} alt="Image Description"/>
            </div></div></div>
        </div>
        </div>
            </div>
    
    )
}
